from django.shortcuts import render, redirect,  get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from .models import Post
from pathlib import Path
from django.contrib import messages
from .models import CustomUser
import pymysql
from django.contrib.auth.models import User
from django.http import JsonResponse


def index(request):
    posts = Post.objects.all()
    return render(request, 'main.html', {'posts': posts})

def search_results(request):

    return render(request, 'search_results.html')

def post(request):
    # MySQL 데이터베이스에서 게시글을 가져옵니다.
    connection = pymysql.connect(
        host="rookies-team5-db.c3w0mgioep1e.us-west-2.rds.amazonaws.com",
        port=3306,
        user="admin",
        password="abc123123",
        database="sampledb",
        autocommit=True
    )
    cursor = connection.cursor()

    # 게시글을 가져오는 쿼리 실행
    query = "SELECT title, content, rating, hashtags, region, image FROM posts_detail ORDER BY post_num DESC"
    cursor.execute(query)
    posts_data = cursor.fetchall()

    # 가져온 게시글 데이터를 딕셔너리 형태로 변환하여 리스트에 저장
    posts = []
    for post_data in posts_data:
        post = {
            'title': post_data[0],  # 제목에 해당하는 필드
            'content': post_data[1],  # 내용에 해당하는 필드
            'rating': post_data[2],  # 별점에 해당하는 필드
            'hashtags': post_data[3],  # 해시태그에 해당하는 필드
            'region' : post_data[4],
            'image' : post_data[5]
        }
        posts.append(post)

    return render(request, 'post.html', {'posts': posts})

    
def posting_new(request):
    if request.method == "POST":
        # 사용자가 입력한 데이터를 가져옵니다.
        region = request.POST.get('region')
        destination = request.POST.get('destination')
        rating = request.POST.get('rating')
        hashtags = request.POST.get('hashtags')
        title = request.POST.get('title')
        content = request.POST.get('content')

        # 파일 업로드 처리
        if 'image' in request.FILES:
            image_file = request.FILES['image']
            # 이미지 파일을 임시 위치에 저장합니다.
            fs = FileSystemStorage()
            filename = fs.save(image_file.name, image_file)
            # 저장된 이미지의 경로를 가져옵니다.
            uploaded_file_path = fs.url(filename)
        else:
            uploaded_file_path = None


        # MySQL 데이터베이스에 연결합니다.
        connection = pymysql.connect(
            host="rookies-team5-db.c3w0mgioep1e.us-west-2.rds.amazonaws.com",
            port=3306,
            user="admin",
            password="abc123123",
            database="sampledb",
            autocommit=True
        )

        # 사용자 정보를 MySQL 데이터베이스에 삽입합니다.
        try:
            with connection.cursor() as cursor:
                # 이미지 파일을 바이너리로 읽어옵니다.
                if uploaded_file_path:
                    with open(uploaded_file_path, "rb") as image_file:
                        image_data = image_file.read()
                else:
                    image_data = None

                # 쿼리를 실행하여 데이터베이스에 데이터를 추가합니다.
                sql = "INSERT INTO posts_detail (region, destination, rating, hashtags, title, content, image) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                cursor.execute(sql, (region, destination, rating, hashtags, title, content, image_data))
                
                messages.success(request, '게시글이 성공적으로 작성되었습니다.')
                return redirect('post')
        finally:
            connection.close()  # 연결을 닫습니다. 
        messages.success(request, '게시글이 성공적으로 작성되었습니다.')
        return redirect('post')
    return render(request, 'posting_new.html')  # 글쓰기 페이지

def posting_change(request):
    if request.method == "GET":
        # GET 요청이 들어오면 해당 게시물의 정보를 가져옵니다.
        post_num = request.GET.get('post_num')
        post = get_object_or_404(Post, pk=post_num)
        
        # 수정 폼을 렌더링합니다.
        return render(request, 'posting_change.html', {'post': post})
    
    elif request.method == "POST":
        # POST 요청이 들어오면 해당 게시물의 정보를 업데이트합니다.
        post_id = request.POST.get('post_num')
        post = get_object_or_404(Post, pk=post_num)
        
        post.region = request.POST.get('region')
        post.destination = request.POST.get('destination')
        post.rating = request.POST.get('rating')
        post.hashtags = request.POST.get('hashtags')
        post.title = request.POST.get('title')
        post.content = request.POST.get('content')
        post.image = request.FILES.get('image') if 'image' in request.FILES else None
        post.save()
        
        # 수정이 완료되면 해당 게시물의 상세 페이지로 이동합니다.
        return redirect('post.html', post_num=post_num)
    
def delete_post(request, post_id):
    if request.method == 'POST':
        post = Post.objects.get(id=post_id)
        post.delete()
        return JsonResponse({'message': '게시물이 성공적으로 삭제되었습니다.'}) # 양

def myinfo(request):
    return render(request, 'myinfo.html') # 내 정보 : 정보 수정

def modify_user(request):
    if request.method == 'POST':
        username = request.user.username
        email = request.POST.get('email')
        new_password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        try:
            # 사용자 정보 가져오기
            user = User.objects.get(username=username)
            
            # 비밀번호 확인 및 업데이트
            if new_password == confirm_password:
                # 비밀번호 업데이트
                user.set_password(new_password)
                user.email = email  # 이메일 업데이트
                user.save()
                
                # MySQL 데이터베이스에도 업데이트
                connection = pymysql.connect(
                    host="rookies-team5-db.c3w0mgioep1e.us-west-2.rds.amazonaws.com",
                    port="3306",
                    user="admin",
                    password="abc123123",
                    database="sampledb",
                    autocommit=True
                )
                cursor = connection.cursor()
                
                # 사용자 정보 업데이트 쿼리 실행
                query = "UPDATE users SET password=%s, email=%s WHERE username=%s"
                cursor.execute(query, (new_password, email, username))
                
                # 성공 메시지
                messages.success(request, '성공적으로 변경되었습니다.')
                
                # 리다이렉션
                return redirect('index')
            else:
                messages.error(request, '비밀번호와 비밀번호 확인이 일치하지 않습니다.')
        except User.DoesNotExist:
            messages.error(request, '해당 사용자가 존재하지 않습니다.')

    return render(request, 'modify_user.html')

def logout_view(request): # 로그아웃
    logout(request)
    return redirect('index')

