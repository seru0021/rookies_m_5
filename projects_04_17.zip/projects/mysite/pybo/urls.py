from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls import include


urlpatterns = [
    path('', views.index, name='index'),
    path('post/', views.post, name='post'),
    path('search/', views.search_results, name='search_results'),
    path('myinfo/', views.myinfo, name='myinfo'),
    path('posting_new/', views.posting_new, name='posting_new'),
    path('modify_user/', views.modify_user, name='modify_user'),
    path('posting_change/', views.posting_change, name='posting_change'),
    path('posting_change/<int:post_num>/', views.posting_change, name='posting_change'),
    path('__debug__/', include('debug_toolbar.urls')),
    path('delete_post/', views.delete_post, name='delete_post'),
]