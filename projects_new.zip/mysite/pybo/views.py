from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from .models import Post
from pathlib import Path
from django.contrib import messages
from .models import CustomUser
import pymysql
from django.contrib.auth.models import User

def index(request):
    posts = Post.objects.all()
    return render(request, 'main.html', {'posts': posts})

def search_results(request):
    return render(request, 'search_results.html')

def post(request):
    # MySQL 데이터베이스에서 게시글을 가져옵니다.
    connection = pymysql.connect(
        host="rookies-team5-db.c3w0mgioep1e.us-west-2.rds.amazonaws.com",
        port=3306,
        user="admin",
        password="abc123123",
        database="sampledb",
        autocommit=True
    )
    cursor = connection.cursor()

    # 게시글을 가져오는 쿼리 실행
    query = "SELECT * FROM posts_detail"
    cursor.execute(query)
    posts_data = cursor.fetchall()

    # 가져온 게시글 데이터를 딕셔너리 형태로 변환하여 리스트에 저장
    posts = []
    for post_data in posts_data:
        post = {
            'title': post_data[3],  # 제목에 해당하는 필드
            'content': post_data[4],  # 내용에 해당하는 필드
            'rating': post_data[5],  # 별점에 해당하는 필드
            'hashtag': post_data[6]  # 해시태그에 해당하는 필드
        }
        posts.append(post)

    return render(request, 'post.html', {'posts': posts})

def posting_new(request):
    if request.method == "POST":
        # 사용자가 입력한 데이터를 가져옵니다.
        region = request.POST.get('region')
        destination = request.POST.get('destination')
        hashtags = request.POST.get('hashtags')
        title = request.POST.get('title')
        content = request.POST.get('content')

        # MySQL 데이터베이스에 연결합니다.
        connection = pymysql.connect(
            host="rookies-team5-db.c3w0mgioep1e.us-west-2.rds.amazonaws.com",
            port=3306,
            user="admin",
            password="abc123123",
            database="sampledb",
            autocommit=True
        )
        cursor = connection.cursor()

        # 사용자 정보를 MySQL 데이터베이스에 삽입합니다.
        query = "INSERT INTO posts_detail (region, destination, hashtags, title, content) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (region, destination, hashtags, title, content))

        # 성공 메시지
        messages.success(request, '게시글이 성공적으로 작성되었습니다.')

        # 홈 페이지로 리다이렉트합니다.
        return redirect('index')

    return render(request, 'posting_new.html')  # 글쓰기 페이지

def myinfo(request):
    return render(request, 'myinfo.html') # 내 정보 : 정보 수정

def modify_user(request):
    if request.method == 'POST':
        username = request.user.username
        email = request.POST.get('email')
        new_password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        try:
            # 사용자 정보 가져오기
            user = User.objects.get(username=username)
            
            # 비밀번호 확인 및 업데이트
            if new_password == confirm_password:
                # 비밀번호 업데이트
                user.set_password(new_password)
                user.email = email  # 이메일 업데이트
                user.save()
                
                # MySQL 데이터베이스에도 업데이트
                connection = pymysql.connect(
                    host="rookies-team5-db.c3w0mgioep1e.us-west-2.rds.amazonaws.com",
                    port=3306,
                    user="admin",
                    password="abc123123",
                    database="sampledb",
                    autocommit=True
                )
                cursor = connection.cursor()
                
                # 사용자 정보 업데이트 쿼리 실행
                query = "UPDATE users SET password=%s, email=%s WHERE username=%s"
                cursor.execute(query, (new_password, email, username))
                
                # 성공 메시지
                messages.success(request, '성공적으로 변경되었습니다.')
                
                # 리다이렉션
                return redirect('index')
            else:
                messages.error(request, '비밀번호와 비밀번호 확인이 일치하지 않습니다.')
        except User.DoesNotExist:
            messages.error(request, '해당 사용자가 존재하지 않습니다.')

    return render(request, 'modify_user.html')

def logout_view(request): # 로그아웃
    logout(request)
    return redirect('index')

